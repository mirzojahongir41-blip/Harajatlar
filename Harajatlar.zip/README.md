# Harajatlar (Kivy)

Kivy asosidagi Harajatlar ilovasi — Android APK-ni GitHub Actions orqali avtomatik qurish uchun tayyorlangan loyiha.

Qurish:
1. GitHub’da yangi repo yarating.
2. ZIP ichidagi fayllarni repo ga yuklang (yoki git yordamida push qiling).
3. GitHub Actions avtomatik ravishda ishga tushadi va build tugagach, Actions → run → Artifacts bo‘limidan `harajatlar-apk` artefaktini yuklab oling.
